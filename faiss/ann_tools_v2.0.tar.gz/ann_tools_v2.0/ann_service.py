#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import numpy as np
import json
import web
import faiss
import struct
import sys
import time

class MyApplication(web.application):
    def run(self, port=8080, *middleware):
        func = self.wsgifunc(*middleware)
        return web.httpserver.runsimple(func, ('0.0.0.0', port))

class GetIndex:

    def POST(self):
        web.header('content-type', 'text/json')
        params = json.loads(web.data())
        vector = params['vectors']
        k = params['k']
        query = params['query']
        p_emb_matrix = np.asarray(vector)
        if 'ef' in params:
            faiss.ParameterSpace().set_index_parameter(FINDEX, "efSearch", int(params['ef']))
        else:
            faiss.ParameterSpace().set_index_parameter(FINDEX, "efSearch", int(2000))
        start_time = time.time()
        D,I = FINDEX.search(p_emb_matrix.astype('float32'), k)
        end_request_time = time.time()
        print("search time %s" % str(end_request_time - start_time))
        passages_list = []
        for offsetList in I:
            passages = []
            for offset in offsetList:
                offset = int(offset)
                line_list = PARA_INDEX[offset]
                passage = "\t".join(line_list)
                passages.append(passage)
            passages_list.append(passages)

        end_para_time = time.time()
        print("para time %s" % str(end_para_time - end_request_time))
        response_object = {"error_code": "0", "error_message": "", "s": D.tolist(), \
            "o":I.tolist(), "p":passages_list,"query":query}
        message = json.dumps(response_object)
        return message


if __name__ == "__main__":
    para_file = sys.argv[1]
    index_file = sys.argv[2]
    port = sys.argv[3]
    global FINDEX
    FINDEX = faiss.read_index(index_file)
    # load para
    global PARA_INDEX
    PARA_INDEX = {}
    line_index = 0
    with open(para_file) as para_doc:
        for line in para_doc:
            line_list = line.strip('\n').split('\t')
            PARA_INDEX[line_index] = line_list[0:-1]
            line_index = line_index + 1
    print("data done")
    urls = (
         '/', 'GetIndex'
    )
    app = MyApplication(urls, globals())
    app.run(port=int(port))

