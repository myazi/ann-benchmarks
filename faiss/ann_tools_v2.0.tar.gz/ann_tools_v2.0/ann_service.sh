#########################################################################
# File Name: ann.sh
# Author: yingwenjie
# mail: yingwenjie.com
# Created Time: Mon 07 Nov 2022 12:56:05 PM CST
#########################################################################
#!/bin/bash

input_para=$1
input_index=$2
port=$3

/mnt/work/yingwenjie/python36/bin/python ann_service.py ${input_para} ${input_index} ${port} 
if [ $? != 0 ]; then
    echo "ann service is fail"
    exit
fi
