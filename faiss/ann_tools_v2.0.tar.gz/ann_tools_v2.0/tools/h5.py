import h5py

#f = h5py.File("aurora_1M/100/elasticsearch_filter_500_1000/angular_768.hdf5", 'r')
s = f["neighbors"]
d = f["distances"]

for i in range(len(s)):
    for j in range(len(s[0])):
        print(str(i) + "\t" + str(s[i,j]) + "\t" + str(d[i,j]))

