#########################################################################
# File Name: train.py
# Author: yingwenjie
# mail: yingwenjie.com
# Created Time: Mon 07 Nov 2022 03:10:38 PM CST
#########################################################################
import argparse
import os
import random
import sys
import h5py
import numpy
import time
import faiss

from ann.algorithms.definitions import (get_definitions, instantiate_algorithm)
from ann.results import store_results
from ann.distance import metrics
from ann.datasets import get_dataset

def run_individual_query(algo, X_train, X_test, distance, count, run_count):

    best_search_time = float('inf')
    for i in range(run_count):
        print('Run %d/%d...' % (i + 1, run_count))
        n_items_processed = [0]

        def single_query(v):
            start = time.time()
            candidates = algo.query(v, count)
            total = (time.time() - start)
            candidates = [(int(idx), float(metrics[distance]['distance'](v, X_train[idx])))
                          for idx in candidates]
            n_items_processed[0] += 1
            if n_items_processed[0] % 1000 == 0:
                print('Processed %d/%d queries...' % (n_items_processed[0], len(X_test)))
            if len(candidates) > count:
                print('warning: algorithm %s returned %d results, but count'
                      ' is only %d)' % (algo, len(candidates), count))
            return (total, candidates)

        results = [single_query(x) for x in X_test]

        total_time = sum(time for time, _ in results)
        total_candidates = sum(len(candidates) for _, candidates in results)
        search_time = total_time / len(X_test)
        avg_candidates = total_candidates / len(X_test)
        best_search_time = min(best_search_time, search_time)

    verbose = hasattr(algo, "query_verbose")
    attrs = {
        "best_search_time": best_search_time,
        "candidates": avg_candidates,
        "expect_extra": verbose,
        "name": str(algo),
        "run_count": run_count,
        "distance": distance,
        "count": int(count)
    }
    additional = algo.get_additional()
    for k in additional:
        attrs[k] = additional[k]
    return (attrs, results)

def run(definition, dataset, count, run_count):
    print(definition)
    algo = instantiate_algorithm(definition)
    assert not definition.query_argument_groups \
           or hasattr(algo, "set_query_arguments"), """\
error: query argument groups have been specified for %s.%s(%s), but the \
algorithm instantiated from it does not implement the set_query_arguments \
function""" % (definition.module, definition.constructor, definition.arguments)

    D, dimension = get_dataset(dataset)
    X_train = numpy.array(D['train'])
    X_test = numpy.array(D['test'])
    X_test = X_test[0:1000]
    distance = D.attrs['distance']
    print("load data done")
    print('got a train set of size (%d * %d)' % (X_train.shape[0], dimension))
    print('got %d queries' % len(X_test))
    try:
        t0 = time.time()
        memory_usage_before = algo.get_memory_usage()
        algo.fit(X_train, dataset)
        build_time = time.time() - t0
        index_size = algo.get_memory_usage() - memory_usage_before
        print('Built index in', build_time)
        print('Index size: ', index_size)

        query_argument_groups = definition.query_argument_groups
        if not query_argument_groups:
            query_argument_groups = [[]]

        for pos, query_arguments in enumerate(query_argument_groups, 1):
            print("Running query argument group %d of %d..." %
                  (pos, len(query_argument_groups)))
            if query_arguments:
                algo.set_query_arguments(*query_arguments)
            descriptor, results = run_individual_query(
                algo, X_train, X_test, distance, count, run_count)
            descriptor["build_time"] = build_time
            descriptor["index_size"] = index_size
            descriptor["algo"] = definition.algorithm
            descriptor["dataset"] = dataset
            store_results(dataset, count, definition,
                          query_arguments, descriptor, results)
    finally:
        algo.done()

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument(
        '--dataset',
        metavar='NAME',
        help='the dataset to load training points from',
        default='test_aurora_1M')
    parser.add_argument(
        "-k", "--count",
        default=100,
        type=int,
        help="the number of near neighbours to search for")
    parser.add_argument(
        '--runs',
        metavar='COUNT',
        help='run each algorithm instance %(metavar)s times and use only'
             ' the best result',
        default=3)
    parser.add_argument(
        '--definitions',
        metavar='FILE',
        help='load algorithm definitions from FILE',
        default='algos_one.yaml')

    args = parser.parse_args()

    dataset, dimension = get_dataset(args.dataset)
    point_type = dataset.attrs.get('point_type', 'float')
    distance = dataset.attrs['distance']
    definitions = get_definitions(
        args.definitions, dimension, point_type, distance, args.count)
    remember_nt = faiss.omp_get_max_threads()
    remember_nt = 16
    
    for definition in definitions:
        faiss.omp_set_num_threads(remember_nt)
        run(definition, args.dataset, args.count, args.runs)
