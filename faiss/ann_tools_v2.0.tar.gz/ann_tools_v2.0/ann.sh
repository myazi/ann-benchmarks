#########################################################################
# File Name: ann.sh
# Author: yingwenjie
# mail: yingwenjie.com
# Created Time: Mon 07 Nov 2022 12:56:05 PM CST
#########################################################################
#!/bin/bash

input_para=$1
input_query=$2
task_name=$3
dim=$4

RESULT="./results"
INDEX="./indexs"

IP_FILE='run_ann.pid'
if [ -f ./$IP_FILE ];then
    date +%Y-%m-%d:%H-%M-%S
    #echo "ann task doing" | mutt yingwenjie@baidu.com -s "last not finish"
    exit
fi
echo "ann PID of this script: $$" > ./$IP_FILE

if [ ! -d ${RESULT} ]; then
    mkdir ${RESULT}
fi

if [ ! -d ${INDEX} ]; then
    mkdir ${INDEX}
fi

/mnt/work/yingwenjie/python36/bin/python data.py --input_para ${input_para} --input_query ${input_query} --task_name ${task_name} --dim ${dim} --count 100
if [ $? != 0 ]; then
    echo "dataset is fail"
    rm -rf $IP_FILE
    exit
fi
/mnt/work/yingwenjie/python36/bin/python run.py --dataset ${task_name} --count 100 
if [ $? != 0 ]; then
    echo "run is fail"
    rm -rf $IP_FILE
fi
/mnt/work/yingwenjie/python36/bin/python result.py --dataset ${task_name} --count 100 
if [ $? != 0 ]; then
    echo "result is fail"
fi

rm -rf $IP_FILE
