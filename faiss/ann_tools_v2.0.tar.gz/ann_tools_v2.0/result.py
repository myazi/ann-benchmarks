#########################################################################
# File Name: result.py
# Author: yingwenjie
# mail: yingwenjie.com
# Created Time: Wed 09 Nov 2022 07:15:47 PM CST
#########################################################################
import os
import numpy as np
import argparse
import h5py

from ann.results import (load_all_results, get_unique_algorithms)
from ann.metrics import all_metrics as metrics
from ann.datasets import get_dataset

def get_or_create_metrics(run):
    if 'metrics' not in run:
        run.create_group('metrics')
    return run['metrics']

def compute_all_metrics_ywj(dataset, res, recompute=True):
    true_nn_distances = np.array(dataset["distances"])
    true_nn_neighbors = np.array(dataset["neighbors"])
    sim_or_dis = dataset.attrs["distance"]
    for i, (properties, run) in enumerate(res):
        algo = properties["algo"]
        algo_name = properties["name"]
        results = {}
        run_distances = np.array(run["distances"])
        run_neighbors = np.array(run["neighbors"])
        times = np.array(run['times'])
        if recompute and 'metrics' in run:
            del run['metrics']
        metrics_cache = get_or_create_metrics(run)
        vs = []
        for name, metric in metrics.items():
            if name == "k-nn_id":
                v = metric["function"](
                        true_nn_neighbors, run_neighbors, metrics_cache, times, properties)
            elif name == "k-nn":
                v = metric["function"](
                    sim_or_dis, true_nn_distances, run_distances, metrics_cache, times, properties)
            else:
                v = metric["function"](
                    true_nn_distances, run_distances, metrics_cache, times, properties)
            vs.append(name + "#" + str(round(v,4)))
        print(algo + "\t" + algo_name + "\t" + "\t".join(vs))

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--dataset',
        metavar="DATASET",
        default='test_aurora_1M')
    parser.add_argument(
        '--count',
        default=100)
    args = parser.parse_args()

    dataset, _ = get_dataset(args.dataset)
    count = int(args.count)
    unique_algorithms = get_unique_algorithms()
    results = load_all_results(args.dataset, count)
    compute_all_metrics_ywj(dataset,
                results)
