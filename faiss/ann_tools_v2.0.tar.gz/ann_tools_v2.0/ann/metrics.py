from __future__ import absolute_import
import numpy as np


def knn_threshold(data, count, epsilon, sim_or_dis="arugula"):
    if (sim_or_dis) != "ip":
        return data[count - 1] + epsilon
    elif sim_or_dis == "ip":
        return data[count - 1] * ( 1 - epsilon)

def epsilon_threshold(data, count, epsilon, sim_or_dis="arugula"):
    if (sim_or_dis) != "ip":
        return data[count - 1] * (1 + epsilon)
    elif sim_or_dis == "ip":
        return data[count - 1] * ( 1 - epsilon)


def get_recall_values(dataset_distances, run_distances, count, threshold,
                      epsilon=1e-3, sim_or_dis="arugula"):
    recalls = np.zeros(len(run_distances))
    for i in range(len(run_distances)):
        t = threshold(dataset_distances[i], count, epsilon, sim_or_dis)
        actual = 0
        for d in run_distances[i][:count]:
            if sim_or_dis !="ip":
                if d <= t:
                    actual += 1
            if sim_or_dis =="ip":
                if d >= t:
                    actual += 1
        recalls[i] = actual
    return (np.mean(recalls) / float(count),
            np.std(recalls) / float(count),
            recalls)

def knn_id(dataset_neighbors, run_neighbors, count, metrics):
    recalls = np.zeros(len(run_neighbors))
    if 'knn_id' not in metrics:
        knn_metrics = metrics.create_group('knn_id')
        for i in range(len(run_neighbors)):
            actual = 0
            for j  in range(count):
                if (run_neighbors[i][j] + 1) in dataset_neighbors[i][:count]:
                    actual += 1
            recalls[i] = actual
        knn_metrics.attrs['mean'] = np.mean(recalls) / float(count)
        knn_metrics.attrs['std'] = np.std(recalls) / float(count)
        knn_metrics['recalls'] = recalls
    return metrics['knn_id']

def knn(sim_or_dis, dataset_distances, run_distances, count, metrics, epsilon=1e-3):
    if 'knn' not in metrics:
        knn_metrics = metrics.create_group('knn')
        mean, std, recalls = get_recall_values(dataset_distances,
                                               run_distances, count,
                                               knn_threshold, epsilon, sim_or_dis)
        knn_metrics.attrs['mean'] = mean
        knn_metrics.attrs['std'] = std
        knn_metrics['recalls'] = recalls
    else:
        print("Found cached result knn")
    return metrics['knn']


def queries_per_second(queries, attrs):
    return 1.0 / attrs["best_search_time"]

def index_size(queries, attrs):
    # TODO(erikbern): should replace this with peak memory usage or something
    return attrs.get("index_size", 0)


def build_time(queries, attrs):
    return attrs["build_time"]


all_metrics = {
    "k-nn_id": {
        "description": "Recall",
        "function": lambda true_neighbors, run_neighbors, metrics, times, run_attrs: knn_id(true_neighbors, run_neighbors, run_attrs["count"], metrics).attrs['mean'],  # noqa
        "worst": float("-inf"),
        "lim": [0.0, 1.03]
    },
    "k-nn": {
        "description": "Recall",
        "function": lambda sim_or_dis, true_distances, run_distances, metrics, times, run_attrs: knn(sim_or_dis, true_distances, run_distances, run_attrs["count"], metrics).attrs['mean'],  # noqa
        "worst": float("-inf"),
        "lim": [0.0, 1.03]
    },
    "qps": {
        "description": "Queries per second (1/s)",
        "function": lambda true_distances, run_distances, metrics, times, run_attrs: queries_per_second(true_distances, run_attrs),  # noqa
        "worst": float("-inf")
    },
    "build": {
        "description": "Build time (s)",
        "function": lambda true_distances, run_distances, metrics, times, run_attrs: build_time(true_distances, run_attrs), # noqa
        "worst": float("inf")
    },
    "indexsize": {
        "description": "Index size (kB)",
        "function": lambda true_distances, run_distances, metrics, times, run_attrs: index_size(true_distances, run_attrs),  # noqa
        "worst": float("inf")
    }
}
