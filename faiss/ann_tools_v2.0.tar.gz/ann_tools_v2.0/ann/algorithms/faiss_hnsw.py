from __future__ import absolute_import
import os
import faiss
import numpy as np
from ann.algorithms.base import BaseANN


class FaissHNSW(BaseANN):
    def __init__(self, metric, method_param):
        self._metric = metric
        self.method_param = method_param
        M = self.method_param["M"]
        efConstruction = self.method_param["efConstruction"]
        self.index_name = "faiss_HNSW_" + "M_" + str(M) + "_efConstruction_" + str(efConstruction)

    def fit(self, X, dataset):
        self.index = faiss.IndexHNSWFlat(len(X[0]), self.method_param["M"], faiss.METRIC_INNER_PRODUCT)
        self.index.hnsw.efConstruction = self.method_param["efConstruction"]
        self.index.verbose = True

        if X.dtype != np.float32:
            X = X.astype(np.float32)
        self.index.add(X)

        index_path = "./indexs/" + dataset
        if not os.path.isdir(index_path):
            os.makedirs(index_path)
        faiss.write_index(self.index, index_path + "/" + str(self.index_name) + ".index")
        faiss.omp_set_num_threads(1)

    def query(self, v, n):
        if self._metric == 'angular':
            v /= np.linalg.norm(v)
        D, I = self.index.search(np.expand_dims(
            v, axis=0).astype(np.float32), n)
        return I[0]

    def set_query_arguments(self, ef):
        faiss.cvar.hnsw_stats.reset()
        self.index.hnsw.efSearch = ef

    def get_additional(self):
        return {"dist_comps": faiss.cvar.hnsw_stats.ndis}

    def __str__(self):
        return 'faiss (%s, ef: %d)' % (self.method_param, self.index.hnsw.efSearch)

    def freeIndex(self):
        del self.p
