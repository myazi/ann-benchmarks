import h5py
import numpy
import os

def get_dataset(file_name):
    hdf5_fn = file_name + ".hdf5"
    hdf5_f = h5py.File(hdf5_fn, 'r')
    dimension = int(hdf5_f.attrs['dimension']) if 'dimension' in hdf5_f.attrs else len(hdf5_f['train'][0])
    return hdf5_f, dimension
